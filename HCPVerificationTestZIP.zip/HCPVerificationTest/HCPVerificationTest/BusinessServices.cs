﻿using System;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Linq;
namespace HCPVerificationTest
{
    [TestClass]
    public class BusinessServices
    {
        private TestContext testContextInstance;
        private IWebDriver driver;
        private bool treePresent;

        [TestMethod]
        public void Does_Business_Service_Have_Groups()
        {
            IsElementPresent(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));

            Assert.AreEqual(treePresent, true);
        }

        [TestMethod]
        public void Does_Business_Service_Have_GroupResources()
        {
            IsElementPresent(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));

            if (treePresent.Equals(true))
            {
                var iTag = driver.FindElement(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));
                iTag.Click();
                var aTag = iTag.FindElement(By.XPath(".."));
                aTag.Click();

                IsElementPresent(By.XPath("//ul[@class='tree-sub-list ng-scope']"));
                Assert.AreEqual(treePresent, true);
                Thread.Sleep(5000);
            }
        }

        [TestMethod]
        public void Does_Business_Service_Have()
        {
            IsElementPresent(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));

            if (treePresent.Equals(true))
            {
                var iTag = driver.FindElement(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));
                iTag.Click();
                var aTag = iTag.FindElement(By.XPath(".."));
                aTag.Click();

                IsElementPresent(By.XPath("//ul[@class='tree-sub-list ng-scope']"));
                Thread.Sleep(5000);

                if (treePresent.Equals(true))
                {
                    driver.FindElement(By.XPath("//div[@class='tree-sub-list-item clearfix ng-scope']")).Click();
                    IsElementPresent(By.Id("99afa9d9-7298-7df6-b071-322bfd5a93a1"));
                    Assert.AreEqual(treePresent, true); 
                }
            }
        }


        bool IsElementPresent(By by)
        {
            try
            {
                driver.FindElement(by);
                treePresent = true;
                return true;
            }
            catch (NoSuchElementException)
            {
                treePresent = false;
                return false;
            }
        }

        [TestInitialize()]
        public void SetupTest()
        {

            string browser = "Firefox";
            switch (browser)
            {
                case "Chrome":
                    driver = new ChromeDriver();
                    break;
                case "Firefox":
                    driver = new FirefoxDriver();
                    break;
                case "IE":
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    driver = new FirefoxDriver();
                    break;

            }

            driver.Url = "https://hcp-inframoncsp-test.azurewebsites.net/";

            // email input
            var email = driver.FindElement(By.Id("i0116"));
            email.SendKeys("");

            // next button press
            var nextBtn1 = driver.FindElement(By.Id("idSIButton9"));
            nextBtn1.Click();

            // password input
            var password = driver.FindElement(By.Id("i0118"));
            password.SendKeys("");
            Thread.Sleep(2000);

            // sign in button press
            var signIn = driver.FindElement(By.Id("idSIButton9"));
            signIn.Click();

            // final button press
            var nextBtn2 = driver.FindElement(By.Id("idBtn_Back"));
            nextBtn2.Click();
            Thread.Sleep(8000);

            var adminNavHamburger = driver.FindElement(By.ClassName("admin-nav-hamburger"));
            adminNavHamburger.Click();
            Thread.Sleep(5000);

            var azureAdmin = driver.FindElement(By.CssSelector("[href*='/BusinessServices'"));
            azureAdmin.Click();
            Thread.Sleep(10000);


        }
    }
}
